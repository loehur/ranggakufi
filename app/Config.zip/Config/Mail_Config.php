<?php

class Mail_Config
{
    public $Host = 'mail.mdl.my.id';
    public $Port = 465;
    public $SMTPSecure = "ssl";
    public $Username = 'cs@mdl.my.id';
    public $Password = 'a123654b';
    public $From = 'cs@mdl.my.id';
    public $FromName = "MDL Laundry";
}
