<?php

class URL
{
    public $BASE_URL = '/web_i/rangga/';
    public $ASSETS_URL = '/web_i/rangga/assets/';
}
